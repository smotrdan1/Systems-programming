import atexit
import sqlite3
from dao import _Vaccines, _Suppliers, _Clinics, _Logistics
from dto import Vaccine


class _Repository:
    def __init__(self):
        self._conn = sqlite3.connect('database.db')
        self.vaccines = _Vaccines(self._conn)
        self.suppliers = _Suppliers(self._conn)
        self.clinics = _Clinics(self._conn)
        self.logistics = _Logistics(self._conn)

    def _close(self):
        self._conn.commit()
        self._conn.close()

    def create_tables(self):
        self._conn.executescript("""
        CREATE TABLE vaccines(
            id INTEGER PRIMARY KEY,
            date NOT NULL,
            supplier INTEGER REFERENCES suppliers(id),
            quantity INTEGER NOT NULL);

        CREATE TABLE suppliers(
            id INTEGER PRIMARY KEY,
            name STRING NOT NULL,
            logistic INTEGER REFERENCES logistics(id));

        CREATE TABLE clinics(
            id INTEGER PRIMARY KEY,
            location STRING NOT NULL,
            demand INTEGER NOT NULL,
            logistic INTEGER REFERENCES logistics(id));
        
        CREATE TABLE logistics(
            id INTEGER PRIMARY KEY,
            name STRING NOT NULL,
            count_sent INTEGER NOT NULL,
            count_received INTEGER NOT NULL);
        """)

    def receive_shipment(self, name, amount, date):
        self.vaccines.insert(Vaccine(0, date, name, amount))
        self.logistics.increase_received(amount, self.suppliers.find(name))

    def send_shipment(self, location, amount):
        self.clinics.decrease_demand(amount, location)
        self.logistics.increase_sent(amount, self.clinics.find(location))
        while amount != 0:
            vaccine = self.vaccines.find_oldest()
            quantity = vaccine.quantity
            id = vaccine.id
            if quantity - amount == 0:
                self.vaccines.reduce_quantity(amount, id)
                self.vaccines.delete(id)
                amount = 0
            elif quantity > amount:
                self.vaccines.reduce_quantity(amount, id)
                amount = 0
            else:
                self.vaccines.reduce_quantity(quantity, id)
                self.vaccines.delete(id)
                amount -= quantity


# the repository singleton
repo = _Repository()
atexit.register(repo._close)