from dto import Supplier, Vaccine, Clinic, Logistic
from repository import repo
import sys
import os


def main():
    repo.create_tables()
    with open(sys.argv[1]) as file:  # read config
        paths = file.readlines()
    path_list = []
    for path in paths:
        p = path.split(',')
        path_list.append(p)
    fix_dates(swap_seperators(path_list))
    length = 0
    for x in range(int(path_list[0][0])):  # add to vaccines table
        length += 1
        list = paths[length].split(',')
        repo.vaccines.insert_config(Vaccine(int(list[0]), list[1], int(list[2]), int(list[3])))
    for x in range(int(path_list[0][1])):  # add to suppliers table
        length += 1
        list = paths[length].split(',')
        repo.suppliers.insert(Supplier(int(list[0]), list[1], int(list[2])))
    for x in range(int(path_list[0][2])):  # add to clinics table
        length += 1
        list = paths[length].split(',')
        repo.clinics.insert(Clinic(int(list[0]), list[1], int(list[2]), int(list[3])))
    for x in range(int(path_list[0][3])):  # add to logistics table
        length += 1
        list = paths[length].split(',')
        repo.logistics.insert(Logistic(int(list[0]), list[1], int(list[2]), int(list[3])))

    with open(sys.argv[2]) as file:  # read orders
        paths = file.readlines()
    open(sys.argv[3], 'w').close()
    for path in paths:
        list = path.split(',')
        if len(list) == 3:
            repo.receive_shipment(list[0], int(list[1]), list[2])
        else:
            repo.send_shipment(list[0], int(list[1]))
        line = str(repo.vaccines.total_inventory) + "," + str(repo.clinics.total_demands) + "," + str(repo.logistics.total_received) + "," + str(repo.logistics.total_sent) + '\n'
        with open(sys.argv[3], 'a') as file:  # write to output
            file.write(line)


def swap_seperators(lst):
    '''
    lst is either a list of list, or a list of tuples.
    will return a a list of list/tuple where all − occurrences been replaced with - .
    This also replace the lst inplace.
    '''
    for j,l in enumerate(lst):
        nl = list(l)
        for i,v in enumerate(nl):
            if isinstance(v,str):
                nl[i] = v.replace('−','-')
        lst[j] = nl if isinstance(l,list) else tuple(nl)
    return lst


def fix_dates(lst):
    '''
    lst is either a list of lists or a list of tuples.
    will return a list/tuple where a dates of YYYY-MM-D been replaced with YYYY-MM-DD
    '''
    for j,l in enumerate(lst):
        nl = list(l)
        for i,v in enumerate(nl):
            if isinstance(v,str) and v.count('-') == 2:
                v = v.split('-')
                v[-1] = '0'+v[-1] if len(v[-1]) == 1 else v[-1]
                nl[i] = '-'.join(v)
        lst[j] = nl if isinstance(l,list) else tuple(nl)
    return lst


if __name__ == '__main__':
    main()
