from dto import Vaccine


class _Vaccines:
    def __init__(self, conn):
        self._conn = conn
        self.id_counter = 1
        self.total_inventory = 0

    def insert_config(self, vaccine):  # in order to keep the original id
        self._conn.execute("""
               INSERT INTO vaccines (id, date, supplier, quantity) VALUES (?, ?, ?, ?)
           """, [vaccine.id, vaccine.date, vaccine.supplier, vaccine.quantity])
        self.id_counter += vaccine.id
        self.total_inventory += vaccine.quantity

    def insert(self, vaccine):
        self._conn.execute("""
               INSERT INTO vaccines (id, date, supplier, quantity) VALUES (?, ?, ?, ?)
           """, [self.id_counter, vaccine.date, vaccine.supplier, vaccine.quantity])
        self.id_counter += 1
        self.total_inventory += vaccine.quantity

    def reduce_quantity(self, amount, id):
        self._conn.execute("""
                UPDATE vaccines SET quantity = quantity - ? WHERE id = ?
        """, [amount, id])
        self.total_inventory -= amount

    def find_oldest(self):  # find the oldest vaccine to reduce
        c = self._conn.cursor()
        c.execute("""
                SELECT id, date, supplier, quantity FROM vaccines ORDER BY date ASC
        """)
        return Vaccine(*c.fetchone())

    def delete(self, id): # delete if reduced to zero
        self._conn.execute("""
                DELETE FROM vaccines WHERE id = ?
        """, [id])


class _Logistics:
    def __init__(self, conn):
        self._conn = conn
        self.total_received = 0
        self.total_sent = 0

    def insert(self, logistic):
        self._conn.execute("""
                INSERT INTO logistics (id, name, count_sent, count_received) VALUES (?, ?, ?, ?)
        """, [logistic.id, logistic.name, logistic.count_sent, logistic.count_received])
        self.total_received += logistic.count_received
        self.total_sent += logistic.count_sent

    def increase_received(self, amount, id):
        self._conn.execute("""
                UPDATE logistics SET count_received = count_received + ? WHERE id = ?
        """, [amount, id])
        self.total_received += amount


    def increase_sent(self, amount, id):
        self._conn.execute("""
                UPDATE logistics SET count_sent = count_sent + ? WHERE id = ?
        """, [amount, id])
        self.total_sent += amount


class _Clinics:
    def __init__(self, conn):
        self._conn = conn
        self.total_demands = 0

    def insert(self, clinic):
        self._conn.execute("""
                INSERT INTO clinics (id, location, demand, logistic) VALUES (?, ?, ?, ?)
        """, [clinic.id, clinic.location, clinic.demand, clinic.logistic])
        self.total_demands += clinic.demand

    def decrease_demand(self, amount, location):
        self._conn.execute("""
                UPDATE clinics SET demand = demand - ? WHERE location = ?
        """, [amount, location])
        self.total_demands -= amount

    def find(self, location):  # find the logistic
        c = self._conn.cursor()
        c.execute("""
                SELECT logistic FROM Clinics WHERE location = ?
            """, [location])

        return c.fetchone()[0]


class _Suppliers:
    def __init__(self, conn):
        self._conn = conn

    def insert(self, supplier):
        self._conn.execute("""
                INSERT INTO suppliers (id, name, logistic) VALUES (?, ?, ?)
        """, [supplier.id, supplier.name, supplier.logistic])

    def find(self, name):  # find the logistic
        c = self._conn.cursor()
        c.execute("""
                SELECT logistic FROM suppliers WHERE name = ?
            """, [name])

        return c.fetchone()[0]
