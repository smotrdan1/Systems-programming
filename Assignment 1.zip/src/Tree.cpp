//
// Created by spl211 on 02/11/2020.
//
using namespace std;
#include "../include/Session.h"
#include <vector>

Tree::Tree(int rootLabel) : node(rootLabel),children() {};
Tree::~Tree(){
    children.clear(); (clear()); ;}
Tree :: Tree(const Tree& tree): node(tree.node), children(){
    for(int i=0; i<(int)tree.children.size(); i++){
        children.push_back(tree.children[i]->clone());
    }
};
Tree& Tree :: operator = (const Tree& tree ){
    if(this==&tree)
        return*this;
    clear();
    node=tree.node;
    children=tree.children;
    return *this;
}  ;
//move constructor
Tree :: Tree (Tree &&tree): node(tree.node), children(){
    for (auto & child : tree.children) {
        children.push_back(child);
    }
    tree.clear();
};
//move assignment operator
Tree &Tree:: operator = (Tree &&Tree ){
    if(this!=&Tree) {
        clear();
        node = Tree.node;
        for (auto &child : Tree.children) {
            children.push_back(child->clone());
        }
        Tree.clear();
    }
    return *this;
};

void Tree::clear(){
    for (auto &child : children) {
        delete child;
        child = nullptr;
    }
        children.clear();
};
void Tree :: addChild(Tree* child) {
    children.push_back(child);
}
void Tree :: addChild(const Tree& child){
    children.push_back(child.clone());
};
Tree* Tree :: createTree(const Session& session, int rootLabel){
    TreeType type = session.getTreeType();
    Tree* TypeReturned;
    if(type==Cycle){TypeReturned=new CycleTree(rootLabel,session.getCycle());}
    if(type==MaxRank){TypeReturned=new MaxRankTree(rootLabel);}
    if(type==Root){TypeReturned= new RootTree(rootLabel);}
    return TypeReturned;
};
int Tree::getnode() const {return node;};

vector<Tree*> Tree::getchildren() const {return children;};

MaxRankTree* MaxRankTree :: clone() const {return new MaxRankTree(*this);};
CycleTree* CycleTree :: clone() const {return new CycleTree(*this);};
RootTree* RootTree :: clone() const {return new RootTree(*this);};


CycleTree ::CycleTree(int rootLabel, int currCycle) : Tree(rootLabel),currCycle(currCycle){};
int CycleTree::traceTree() {
    int i = 0;
    Tree* curr = this;
    while(i<currCycle && !curr->getchildren().empty()) {
        curr = curr->getchildren()[0];
        i++;
    }

    return curr->getnode();
}

MaxRankTree ::  MaxRankTree(int rootLabel): Tree(rootLabel){};

int MaxRankTree::MaxRank(Tree* tree){
    int ans = tree->getchildren().size();
    vector<Tree*> treeChildren = tree->getchildren();
    int size = treeChildren.size();
    for(int i=0;i<size;i++){
        ans = std::max(ans, MaxRank(treeChildren[i]));
    }
    return ans;
}

int MaxRankTree:: traceTree(){
    int max = MaxRank(this);
    queue<Tree*> list;
    list.push(this);
    while(!list.empty()){
        Tree* current = list.front();
        list.pop();
        int size = current->getchildren().size();
        if(size==max){
            return current->getnode();
        }
        else{
            for(int i=0;i<size;i++){
                list.push(current->getchildren()[i]);
            }
        }
    }
    return 0;
}
RootTree :: RootTree(int rootLabel) : Tree(rootLabel) {};

int RootTree::traceTree() {return getnode();};