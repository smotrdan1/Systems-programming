//
// Created by spl211 on 02/11/2020.
//
using namespace std;
#include <iostream>
#include <vector>
#include "../include/Graph.h"
#include "../include/Session.h"
#include <queue>
Graph::Graph(): edges(), infected(){};
Graph :: Graph(vector<std::vector<int>> matrix) : edges(matrix),infected(matrix.size(),false)  {};
Graph :: Graph(const Graph& g): edges(g.edges), infected(g.infected) {};

Graph& Graph:: operator = (const Graph& g ){
    if(this==&g)
        return*this;
    clear();
    edges=g.edges;
    infected=g.infected;
    return *this;
}  ;

vector<vector<int>> &Graph::getEdges() {
    return edges;
}
vector<bool> Graph::getInfected() {
    return infected;
}


void Graph :: infectNode(int nodeInd){
    infected[nodeInd]=true;
};
bool Graph :: isInfected(int nodeInd){
    if(infected[nodeInd])
        return true;
    return false;
};

vector<int> Graph:: GetNeighbors(int nodeInd){
    vector<int> neighbors;
    for(int i=0;i<(int)edges[0].size();i++){
        if(edges[nodeInd][i]==1)
            neighbors.push_back(i);
    }
    return neighbors;
};
void Graph::clear(){
    edges.clear();
    infected.clear();
};
void Graph:: RemoveEdge(int j,int i) {
    edges[j][i] = 0;
    edges[i][j] = 0;
};