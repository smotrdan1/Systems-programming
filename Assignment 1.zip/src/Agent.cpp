//
// Created by spl211 on 03/11/2020.
//
using namespace std;
#include <vector>
#include "../include/Agent.h"

Agent::Agent(){};
Agent::~Agent() = default;;
ContactTracer ::  ContactTracer()= default;;
Virus::Virus(int nodeInd):nodeInd(nodeInd){};
Virus* Virus :: clone() const {return new Virus(*this);}
ContactTracer* ContactTracer :: clone() const {return new ContactTracer(*this);}

void ContactTracer :: act(Session& session) {
    if (!session.infectedIsEmpty()) {
        int infectedNode = session.dequeueInfected();
        Tree *tree = session.Bfs(infectedNode);
        int node = tree->traceTree();
        delete tree;
        vector<int> Neighbors = session.getGraph().GetNeighbors(node);
        int size = session.getGraph().GetNeighbors(node).size();
        for (int i = 0; i < size; i++) {
            session.getGraph().RemoveEdge(node, Neighbors[i]);
        }
    }
};

void Virus::act(Session &session) {

    if (!session.getGraph().isInfected(nodeInd)) {
        session.getGraph().infectNode(nodeInd);
        session.enqueueInfected(nodeInd);
    }
    vector<int> IncidentNodes=session.getGraph().GetNeighbors(nodeInd);
    int i = 0;
    int size =IncidentNodes.size();
    while(i<size && !session.virusFree(IncidentNodes[i])){
        i++;
    }
    if(i<size) {
        Virus newVirus = Virus(IncidentNodes[i]);
        session.addAgent(newVirus);
        session.spreadVirus(IncidentNodes[i]);
    }
}