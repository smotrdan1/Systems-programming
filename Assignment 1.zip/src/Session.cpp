//
// Created by spl211 on 03/11/2020.
//
using namespace std;
#include "../include/Session.h"
#include "fstream"
#include <vector>
#include "../include/Agent.h"
#include "../include/json.hpp"
using json= nlohmann:: json;
//constructor
Session::Session(const std::string &path): g(),treeType(MaxRank),agents(),infected(), cycle(0), hasVirus(){
    ifstream i(path);
    json j;
    i >> j;
    if (j["tree"] == "M")
        treeType = MaxRank;
    if (j["tree"] == "C")
        treeType = Cycle;
    if (j["tree"] == "R")
        treeType = Root;
    g = Graph(j["graph"]);
    vector<bool> VirusVector(g.getEdges().size(),false);
    hasVirus = VirusVector;
    for(auto& agent: j["agents"] ){
        if (agent[0] == "C")
            agents.push_back(new ContactTracer());
        else {
            agents.push_back(new Virus(agent[1]));
            spreadVirus(agent[1]);
        }
    }
};
//copy constructor
Session::Session(const Session& session):g(session.g),treeType(session.treeType),agents(), infected(session.infected), cycle(session.cycle), hasVirus(session.hasVirus) {
    for (auto agent : session.agents) {
        Agent* newAgent = agent->clone();
        agents.push_back(newAgent);
    }
}
//copy assignment operator
Session &Session:: operator = (const Session& session ){
    if(this==&session)
        return*this;
    g = session.g;
    treeType = session.treeType;
    infected = session.infected;
    hasVirus = session.hasVirus;
    cycle = session.cycle;
    clear();

    for(int i=0; i<(int)agents.size();i++)
        if(agents[i]) delete agents[i];
    for (int i=0; i<(int)session.agents.size(); i++) {
        Agent* newAgent = session.agents[i]->clone();
        agents.push_back(newAgent);
    }
    return *this;
};
//destructor
Session::~Session(){//if (\\!agents.empty()) agents.clear();
    clear(); };
//move constructor
Session::Session(Session &&session): g(session.g),treeType(session.treeType),agents(), infected(session.infected),cycle(session.cycle), hasVirus(session.hasVirus){
    for (auto & agent : session.agents) {
        agents.push_back(agent);
        agent = nullptr;
    }
};
//move assignment operator
Session &Session:: operator = (Session &&session ){
    if(this==&session)
        return*this;
    g = session.g;
    cycle = session.cycle;
    treeType = session.treeType;
    for(int i=0; i<(int)agents.size();i++)
        if(agents[i]) delete agents[i];
    for (auto & agent : session.agents) {
        agents.push_back(agent);
        agent = nullptr;
    }
    infected = session.infected;
    hasVirus = session.hasVirus;
    clear();
    return *this;

};

void Session::simulate() {
    int size = 0;
    while((int)agents.size() != size) {
        size = agents.size();
        int i = 0;
        while (i < size) {
            agents[i]->act(*this);
            i++;
        }
        cycle++;
    }
    vector<int> infectedOutput;
    int infectedSize = g.getInfected().size();
    for(int i = 0; i<infectedSize; i++){
        if(g.isInfected(i))
            infectedOutput.push_back(i);
    }

    json j;
    j["graph"] = g.getEdges();
    j["infected"] = infectedOutput;
    std::ofstream i("./output.json");
    i << j;

};

void Session:: addAgent(const Agent& agent){
    Agent *clone=agent.clone();
    agents.push_back(clone);
};
void Session:: setGraph(const Graph& graph){
    g = graph;
};

void Session:: enqueueInfected(int node){
    infected.push(node);
};
int Session:: dequeueInfected(){
    int toReturn = infected.front();
    infected.pop();
    return toReturn;
};
TreeType Session:: getTreeType() const{
    return treeType;
};
Graph& Session:: getGraph(){
    return g;
};
int Session::getCycle() const {
    return cycle;
}
void Session ::  clear() {
    for(int i=0;i<(int)agents.size();i++){
        delete agents[i];
    }

}

Tree* Session::Bfs(int rootLabel) {

    vector<std::vector<int>> Edges = g.getEdges();
    queue<Tree*> list;
    vector<bool> visited(Edges.size(),false);
    Tree* tree = Tree::createTree(*this,rootLabel);
    list.push(tree);
    visited[rootLabel]=true;
    while (!list.empty()) {
        Tree* v = list.front();
        list.pop();
        for (int i = 0; i < (int) Edges.size(); i++) {
            if (Edges[v->getnode()][i] == 1) {
                if (!visited[i]) {
                    Tree* tmpTree = Tree::createTree(*this,i);
                    list.push(tmpTree);
                    v->addChild(tmpTree);
                    visited[i]=true;
                }
            }
        }
    }
    return tree;
}
bool Session::infectedIsEmpty() {return infected.empty();}

bool Session::virusFree(int node) {return !hasVirus[node];}

void Session::spreadVirus(int node) {hasVirus[node]=true;}