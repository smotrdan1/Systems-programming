#ifndef TREE_H_
#define TREE_H_

#include <vector>
using namespace std;

class Session;

class Tree{
public:
    Tree(int rootLabel);
    virtual ~Tree();
    Tree(const Tree& tree);
    Tree& operator = (const Tree& tree );
    Tree(Tree &&Tree);
    Tree& operator = (Tree &&Tree);
    void clear();
    void addChild(Tree* child);
    void addChild(const Tree& child);
    static Tree* createTree(const Session& session, int rootLabel);
    virtual Tree* clone() const=0;
    virtual int traceTree()=0;
    int getnode() const;
    vector<Tree*> getchildren() const;

private:
    int node;
    std::vector<Tree*> children;
};

class CycleTree: public Tree{
public:
    CycleTree(int rootLabel, int currCycle);
    virtual int traceTree();
    virtual CycleTree* clone() const;
private:
    int currCycle;
};

class MaxRankTree: public Tree{
public:
    MaxRankTree(int rootLabel);
    virtual int traceTree();
    virtual MaxRankTree* clone() const;
    int MaxRank(Tree*);

};

class RootTree: public Tree{
public:
    RootTree(int rootLabel);
    virtual int traceTree();
    virtual RootTree* clone() const;
};

#endif