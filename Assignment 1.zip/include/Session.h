#ifndef SESSION_H_
#define SESSION_H_

#include <vector>
#include <string>
#include "Graph.h"
#include <queue>


class Agent;

enum TreeType{
    Cycle,
    MaxRank,
    Root
};

class Session{
public:
    Session(const std::string& path);
    Session(const Session& session);
    Session& operator = (const Session &session);
    virtual ~Session();
    Session(Session &&session);
    Session& operator = (Session &&session);

    void simulate();
    void addAgent(const Agent& agent);
    void setGraph(const Graph& graph);

    void enqueueInfected(int node);
    int dequeueInfected();
    TreeType getTreeType() const;
    Graph& getGraph();
    int getCycle() const;
    void clear();
    Tree* Bfs(int rootlabel);
    bool infectedIsEmpty();
    bool virusFree(int node);
    void spreadVirus(int node);


private:
    Graph g;
    TreeType treeType;
    std::vector<Agent*> agents;
    queue<int> infected;
    int cycle;
    vector<bool> hasVirus;
};

#endif