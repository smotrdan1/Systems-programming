#ifndef GRAPH_H_
#define GRAPH_H_
#include "Tree.h"
#include <vector>
using namespace std;
class Graph{
public:
    Graph();
    Graph(std::vector<std::vector<int>> matrix);
    Graph(const Graph& g );
    Graph& operator = (const Graph& g);
    void infectNode(int nodeInd);
    bool isInfected(int nodeInd);
    vector<int> GetNeighbors(int nodeInd);
    void clear();
    void RemoveEdge(int j,int i);
    vector<vector<int>> &getEdges();
    vector<bool> getInfected();

private:
    std::vector<std::vector<int>> edges;
    std::vector<bool> infected;
};

#endif